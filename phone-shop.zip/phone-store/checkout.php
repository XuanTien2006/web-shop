<?php
require __DIR__ . '/includes/bootstrap.php';
$user = require_login();
$items = cart_items();
if (!$items) { flash('Giỏ hàng đang trống.', 'err'); redirect('cart.php'); }

$f = ['name' => $user['full_name'], 'phone' => $user['phone'], 'address' => '', 'note' => ''];
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($f as $k => $_) $f[$k] = trim((string)($_POST[$k] ?? ''));
    if ($f['name'] === '' || $f['address'] === '') $err = 'Vui lòng nhập họ tên và địa chỉ nhận hàng.';
    elseif (!preg_match('/^[0-9 +]{9,15}$/', $f['phone'])) $err = 'Số điện thoại không hợp lệ.';
    else {
        $pdo = db();
        try {
            $pdo->beginTransaction();
            $total = 0;
            foreach ($items as $i) {
                $ok = q('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [$i['qty'], $i['id'], $i['qty']])->rowCount();
                if (!$ok) throw new RuntimeException('"' . $i['name'] . '" không đủ hàng, hãy giảm số lượng.');
                $total += $i['qty'] * (int)$i['price'];
            }
            $code = 'DH' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));
            q('INSERT INTO orders (code, user_id, customer_name, phone, address, note, total, status, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
              [$code, $user['id'], $f['name'], $f['phone'], $f['address'], mb_substr($f['note'], 0, 255), $total, 'pending', now()]);
            $oid = (int)$pdo->lastInsertId();
            foreach ($items as $i) {
                q('INSERT INTO order_items (order_id, product_id, name, price, qty) VALUES (?,?,?,?,?)', [$oid, $i['id'], $i['name'], $i['price'], $i['qty']]);
            }
            $pdo->commit();
            $_SESSION['cart'] = [];
            flash('Đặt hàng thành công. Chúng tôi sẽ gọi xác nhận trước khi giao.');
            redirect('order.php?code=' . $code);
        } catch (RuntimeException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $err = $ex->getMessage();
        }
    }
}
$title = 'Đặt hàng';
include __DIR__ . '/includes/header.php';
?>
<h1 class="pt">Đặt hàng</h1>
<div class="cartwrap">
  <form method="post" class="panel stack"><?= csrf_field() ?>
    <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
    <label>Họ và tên<input type="text" name="name" value="<?= e($f['name']) ?>" required></label>
    <label>Số điện thoại<input type="tel" name="phone" value="<?= e($f['phone']) ?>" required></label>
    <label>Địa chỉ nhận hàng<input type="text" name="address" value="<?= e($f['address']) ?>" required></label>
    <label>Ghi chú (tùy chọn)<input type="text" name="note" value="<?= e($f['note']) ?>" maxlength="255"></label>
    <p class="note">Thanh toán khi nhận hàng (COD).</p>
    <button class="btn">Xác nhận đặt hàng</button>
  </form>
  <aside class="sum">
    <h2>Đơn hàng của bạn</h2>
    <?php foreach ($items as $i): ?>
      <div class="row"><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span><span class="num"><?= money($i['line']) ?></span></div>
    <?php endforeach; ?>
    <div class="total"><span>Tổng cộng</span><b><?= money(cart_total($items)) ?></b></div>
  </aside>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
