</main>
<footer class="site"><div class="wrap">© <?= date('Y') ?> <?= e(cfg('site_name')) ?> · Website bán điện thoại di động trực tuyến (PHP + MySQL)</div></footer>
</body>
</html>
