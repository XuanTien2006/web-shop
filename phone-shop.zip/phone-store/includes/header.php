<?php
/** @var string $title */
$user = current_user();
$flash = flash();
$brands = q('SELECT id, name FROM brands WHERE id IN (SELECT brand_id FROM products) ORDER BY name')->fetchAll();
?><!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? cfg('site_name')) ?> · <?= e(cfg('site_name')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600&family=Bricolage+Grotesque:wght@600;700;800&display=swap">
<link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<header class="top">
  <div class="wrap bar">
    <a class="logo" href="<?= e(url()) ?>"><i></i><?= e(cfg('site_name')) ?></a>
    <nav class="nav" aria-label="Menu chính">
      <a href="<?= e(url('index.php#san-pham')) ?>">Sản phẩm</a>
      <a href="<?= e(url('contact.php')) ?>">Liên hệ</a>
      <?php if ($user): ?><a href="<?= e(url('orders.php')) ?>">Đơn của tôi</a><?php endif; ?>
      <?php if (is_admin()): ?><a href="<?= e(url('admin/')) ?>">Quản trị</a><?php endif; ?>
    </nav>
    <form class="search" action="<?= e(url('index.php')) ?>" method="get" role="search">
      <input type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Nhập từ khóa, ví dụ: Galaxy" aria-label="Tìm kiếm sản phẩm">
      <button class="btn sm">Tìm</button>
    </form>
    <div class="actions">
      <?php if ($user): ?>
        <span class="who">Xin chào, <?= e($user['full_name'] ?: $user['username']) ?></span>
        <form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button class="btn ghost sm">Đăng xuất</button></form>
      <?php else: ?>
        <a class="btn ghost sm" href="<?= e(url('login.php')) ?>">Đăng nhập</a>
        <a class="btn ghost sm" href="<?= e(url('register.php')) ?>">Đăng ký</a>
      <?php endif; ?>
      <a class="btn sm" href="<?= e(url('cart.php')) ?>">Giỏ hàng<span class="badge"><?= cart_count() ?></span></a>
    </div>
  </div>
</header>
<main class="wrap page">
<?php if ($flash): ?><div class="flash <?= $flash[1] === 'err' ? 'err' : 'ok' ?>" role="status"><?= e($flash[0]) ?></div><?php endif; ?>
