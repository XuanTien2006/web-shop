<?php
declare(strict_types=1);

$GLOBALS['cfg'] = require __DIR__ . '/../config.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

define('ROOT_DIR', dirname(__DIR__));
$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
$base = $docRoot ? str_replace('\\', '/', substr(ROOT_DIR, strlen($docRoot))) : '';
define('BASE_URL', rtrim($base, '/'));
define('IMG_DIR', ROOT_DIR . '/assets/img/products');

function cfg(string $k) { return $GLOBALS['cfg'][$k]; }

/* ---------- Cơ sở dữ liệu ---------- */
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
    if (cfg('db_driver') === 'sqlite') {
        $pdo = new PDO('sqlite:' . cfg('sqlite_file'), null, null, $opt);
        $pdo->exec('PRAGMA foreign_keys = ON');
    } else {
        $dsn = 'mysql:host=' . cfg('db_host') . ';port=' . cfg('db_port') . ';dbname=' . cfg('db_name') . ';charset=utf8mb4';
        $opt[PDO::ATTR_EMULATE_PREPARES] = false;
        $pdo = new PDO($dsn, cfg('db_user'), cfg('db_pass'), $opt);
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute($p); return $s; }
function now(): string { return date('Y-m-d H:i:s'); }

/* ---------- Tiện ích hiển thị ---------- */
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url(string $path = ''): string { return BASE_URL . '/' . ltrim($path, '/'); }
function money(int $n): string { return number_format($n, 0, ',', '.') . ' ₫'; }
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function slugify(string $s): string {
    $s = mb_strtolower($s, 'UTF-8');
    $s = strtr($s, ['đ' => 'd']);
    $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    $s = $t !== false && $t !== '' ? $t : $s;
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-') ?: 'san-pham';
}
const STATUS = [
    'pending' => 'Chờ xác nhận', 'confirmed' => 'Đã xác nhận', 'shipping' => 'Đang giao',
    'done' => 'Hoàn tất', 'cancelled' => 'Đã hủy',
];

/* ---------- Flash message ---------- */
function flash(?string $msg = null, string $type = 'ok') {
    if ($msg !== null) { $_SESSION['flash'] = [$msg, $type]; return; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}

/* ---------- CSRF ---------- */
function csrf_token(): string {
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(24));
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    $ok = isset($_POST['csrf']) && hash_equals(csrf_token(), (string)$_POST['csrf']);
    if (!$ok) { http_response_code(400); exit('Phiên làm việc không hợp lệ. Hãy tải lại trang và thử lại.'); }
}

/* ---------- Đăng nhập, phân quyền ---------- */
function current_user(): ?array {
    static $u = false;
    if ($u === false) {
        $u = isset($_SESSION['uid']) ? (q('SELECT * FROM users WHERE id = ?', [$_SESSION['uid']])->fetch() ?: null) : null;
    }
    return $u;
}
function is_admin(): bool { $u = current_user(); return $u && $u['role'] === 'admin'; }
function require_login(): array {
    $u = current_user();
    if (!$u) { flash('Vui lòng đăng nhập để tiếp tục.', 'err'); $_SESSION['next'] = $_SERVER['REQUEST_URI'] ?? ''; redirect('login.php'); }
    return $u;
}
function require_admin(): array {
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') { http_response_code(403); exit('Bạn không có quyền truy cập trang quản trị.'); }
    return $u;
}
function login_user(array $u): void { session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id']; }

/* ---------- Giỏ hàng (lưu trong session: product_id => số lượng) ---------- */
function cart(): array { return $_SESSION['cart'] ?? []; }
function cart_count(): int { return array_sum(cart()); }
function cart_items(): array {
    $c = cart(); if (!$c) return [];
    $in = implode(',', array_fill(0, count($c), '?'));
    $rows = q("SELECT * FROM products WHERE id IN ($in)", array_keys($c))->fetchAll();
    $out = [];
    foreach ($rows as $r) { $r['qty'] = min($c[$r['id']], max(1, (int)$r['stock'])); $r['line'] = $r['qty'] * (int)$r['price']; $out[] = $r; }
    return $out;
}
function cart_total(array $items): int { return array_sum(array_column($items, 'line')); }

/* ---------- Ảnh sản phẩm: ảnh thật nếu có file, nếu không thì hình điện thoại dự phòng ---------- */
function product_img(array $p, string $class = ''): string {
    $f = $p['image'] ?? '';
    if ($f === '' && !empty($p['slug'])) {            // tự nhận ảnh chép tay: <slug>.jpg|png|webp
        foreach (['jpg', 'jpeg', 'png', 'webp'] as $x) if (is_file(IMG_DIR . '/' . $p['slug'] . '.' . $x)) { $f = $p['slug'] . '.' . $x; break; }
    }
    if ($f !== '' && is_file(IMG_DIR . '/' . basename($f))) {
        return '<img class="pimg ' . e($class) . '" src="' . e(url('assets/img/products/' . basename($f))) . '" alt="' . e($p['name']) . '" loading="lazy">';
    }
    $pal = [['#ffd36a', '#f08a3c'], ['#8ee0ff', '#2d7be0'], ['#3a3f4c', '#0b0d12'], ['#ff9a9e', '#c2185b'], ['#b8f0c8', '#1f9d6b'], ['#d9c2ff', '#6a4bd8']];
    [$a, $b] = $pal[((int)$p['id']) % count($pal)];
    return '<span class="phone ' . e($class) . '" style="--c1:' . $a . ';--c2:' . $b . '" role="img" aria-label="' . e($p['name']) . '"><span class="scr"></span></span>';
}

/* ---------- Upload ảnh ---------- */
function save_upload(array $file, string $slug): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, null];
    if ($file['error'] !== UPLOAD_ERR_OK) return [null, 'Tải ảnh lên thất bại (mã lỗi ' . $file['error'] . ').'];
    if ($file['size'] > cfg('max_upload_bytes')) return [null, 'Ảnh quá lớn, tối đa 3MB.'];
    $info = @getimagesize($file['tmp_name']);
    $ext = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$info[2] ?? 0] ?? null;
    if (!$ext) return [null, 'Chỉ nhận ảnh JPG, PNG hoặc WEBP.'];
    if (!is_dir(IMG_DIR)) mkdir(IMG_DIR, 0755, true);
    $name = $slug . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], IMG_DIR . '/' . $name)) return [null, 'Không lưu được file ảnh, kiểm tra quyền ghi thư mục assets/img/products.'];
    return [$name, null];
}
function delete_image(string $f): void {
    $p = IMG_DIR . '/' . basename($f);
    if ($f !== '' && is_file($p) && !str_starts_with(basename($f), 'seed-')) @unlink($p);
}
