<?php
require __DIR__ . '/includes/bootstrap.php';
$user = require_login();
$rows = q('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC', [$user['id']])->fetchAll();
$title = 'Đơn của tôi';
include __DIR__ . '/includes/header.php';
?>
<h1 class="pt">Đơn của tôi</h1>
<?php if (!$rows): ?><p class="empty">Bạn chưa có đơn hàng nào. <a href="<?= e(url()) ?>">Mua sắm ngay</a></p>
<?php else: ?>
<div class="tblbox"><table class="tbl"><thead><tr><th>Mã đơn</th><th>Ngày đặt</th><th>Tổng tiền</th><th>Trạng thái</th></tr></thead><tbody>
<?php foreach ($rows as $o): ?>
  <tr><td><a href="<?= e(url('order.php?code=' . $o['code'])) ?>"><?= e($o['code']) ?></a></td><td><?= e($o['created_at']) ?></td><td class="num"><?= money((int)$o['total']) ?></td><td><span class="pill s-<?= e($o['status']) ?>"><?= e(STATUS[$o['status']]) ?></span></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
