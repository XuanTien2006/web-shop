<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect('');
$f = ['username' => '', 'full_name' => '', 'email' => '', 'phone' => ''];
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($f as $k => $_) $f[$k] = trim((string)($_POST[$k] ?? ''));
    $pw = (string)($_POST['password'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_.]{3,30}$/', $f['username'])) $err = 'Tên đăng nhập gồm 3-30 ký tự: chữ không dấu, số, dấu chấm hoặc gạch dưới.';
    elseif (strlen($pw) < 6) $err = 'Mật khẩu cần ít nhất 6 ký tự.';
    elseif ($pw !== (string)($_POST['password2'] ?? '')) $err = 'Hai mật khẩu không khớp.';
    elseif ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $err = 'Email không hợp lệ.';
    elseif ($f['phone'] !== '' && !preg_match('/^[0-9 +]{9,15}$/', $f['phone'])) $err = 'Số điện thoại không hợp lệ.';
    elseif (q('SELECT 1 FROM users WHERE username = ?', [$f['username']])->fetch()) $err = 'Tên đăng nhập đã tồn tại, hãy chọn tên khác.';
    else {
        q('INSERT INTO users (username, password_hash, full_name, email, phone, role, created_at) VALUES (?,?,?,?,?,?,?)',
          [$f['username'], password_hash($pw, PASSWORD_DEFAULT), $f['full_name'], $f['email'], $f['phone'], 'customer', now()]);
        $id = (int)db()->lastInsertId();
        login_user(['id' => $id]);
        flash('Đăng ký thành công. Chào mừng bạn!');
        redirect('');
    }
}
$title = 'Đăng ký';
include __DIR__ . '/includes/header.php';
?>
<form method="post" class="panel stack narrow"><?= csrf_field() ?>
  <h1>Đăng ký tài khoản</h1>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <label>Tên đăng nhập<input type="text" name="username" value="<?= e($f['username']) ?>" required autocomplete="username"></label>
  <label>Họ và tên<input type="text" name="full_name" value="<?= e($f['full_name']) ?>" autocomplete="name"></label>
  <label>Email<input type="text" name="email" value="<?= e($f['email']) ?>" autocomplete="email"></label>
  <label>Số điện thoại<input type="tel" name="phone" value="<?= e($f['phone']) ?>" autocomplete="tel"></label>
  <label>Mật khẩu<input type="password" name="password" required autocomplete="new-password"></label>
  <label>Nhập lại mật khẩu<input type="password" name="password2" required autocomplete="new-password"></label>
  <button class="btn">Tạo tài khoản</button>
  <p class="note">Đã có tài khoản? <a href="<?= e(url('login.php')) ?>">Đăng nhập</a></p>
</form>
<?php include __DIR__ . '/includes/footer.php'; ?>
