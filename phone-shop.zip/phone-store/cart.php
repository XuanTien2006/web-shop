<?php
require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $act = $_POST['action'] ?? '';
    $p = $id ? q('SELECT id, name, stock FROM products WHERE id = ?', [$id])->fetch() : null;
    if ($act === 'add' && $p) {
        $qty = max(1, (int)($_POST['qty'] ?? 1));
        $new = ($_SESSION['cart'][$id] ?? 0) + $qty;
        $_SESSION['cart'][$id] = min($new, max(1, (int)$p['stock']));
        flash('Đã thêm "' . $p['name'] . '" vào giỏ hàng.');
        redirect('cart.php');
    } elseif ($act === 'set' && $p) {
        $qty = (int)($_POST['qty'] ?? 0);
        if ($qty <= 0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id] = min($qty, max(1, (int)$p['stock']));
    } elseif ($act === 'remove') {
        unset($_SESSION['cart'][$id]);
    } elseif ($act === 'clear') {
        $_SESSION['cart'] = [];
    }
    redirect('cart.php');
}

$title = 'Giỏ hàng';
$items = cart_items();
include __DIR__ . '/includes/header.php';
?>
<h1 class="pt">Giỏ hàng</h1>
<?php if (!$items): ?>
  <p class="empty">Giỏ hàng đang trống. <a href="<?= e(url()) ?>">Tiếp tục mua sắm</a></p>
<?php else: ?>
<div class="cartwrap">
  <div class="tblbox"><table class="tbl">
    <thead><tr><th>Sản phẩm</th><th>Đơn giá</th><th>Số lượng</th><th>Thành tiền</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($items as $i): ?>
      <tr>
        <td><div class="cell"><div class="thumb"><?= product_img($i) ?></div><a href="<?= e(url('product.php?slug=' . $i['slug'])) ?>"><?= e($i['name']) ?></a></div></td>
        <td class="num"><?= money((int)$i['price']) ?></td>
        <td><form method="post" class="inl"><?= csrf_field() ?><input type="hidden" name="action" value="set"><input type="hidden" name="id" value="<?= (int)$i['id'] ?>">
          <input type="number" name="qty" value="<?= (int)$i['qty'] ?>" min="0" max="<?= (int)$i['stock'] ?>" aria-label="Số lượng"><button class="btn ghost sm">Cập nhật</button></form></td>
        <td class="num"><?= money($i['line']) ?></td>
        <td><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="id" value="<?= (int)$i['id'] ?>"><button class="btn ghost sm">Xóa</button></form></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <aside class="sum">
    <div class="total"><span>Tổng cộng</span><b><?= money(cart_total($items)) ?></b></div>
    <a class="btn full" href="<?= e(url('checkout.php')) ?>">Tiến hành đặt hàng</a>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="clear"><button class="btn ghost full">Xóa toàn bộ giỏ</button></form>
  </aside>
</div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
