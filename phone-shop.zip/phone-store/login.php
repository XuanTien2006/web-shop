<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect('');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $u = q('SELECT * FROM users WHERE username = ?', [trim((string)($_POST['username'] ?? ''))])->fetch();
    if ($u && password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) {
        $next = $_SESSION['next'] ?? ''; unset($_SESSION['next']);
        login_user($u);
        // chỉ cho phép chuyển hướng nội bộ
        if ($next && str_starts_with($next, BASE_URL . '/') && !str_starts_with($next, '//')) { header('Location: ' . $next); exit; }
        redirect($u['role'] === 'admin' ? 'admin/' : '');
    }
    $err = 'Sai tên đăng nhập hoặc mật khẩu.';
}
$title = 'Đăng nhập';
include __DIR__ . '/includes/header.php';
?>
<form method="post" class="panel stack narrow"><?= csrf_field() ?>
  <h1>Đăng nhập tài khoản</h1>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <label>Tên đăng nhập<input type="text" name="username" required autocomplete="username" autofocus></label>
  <label>Mật khẩu<input type="password" name="password" required autocomplete="current-password"></label>
  <button class="btn">Đăng nhập</button>
  <p class="note">Chưa có tài khoản? <a href="<?= e(url('register.php')) ?>">Đăng ký</a></p>
</form>
<?php include __DIR__ . '/includes/footer.php'; ?>
