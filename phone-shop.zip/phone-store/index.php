<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Điện thoại chính hãng';

$kw = trim((string)($_GET['q'] ?? ''));
$brand = (int)($_GET['brand'] ?? 0);
$sort = $_GET['sort'] ?? 'new';
$page = max(1, (int)($_GET['page'] ?? 1));
$per = cfg('per_page');

$where = []; $args = [];
if ($kw !== '') { $where[] = '(p.name LIKE ? OR b.name LIKE ?)'; $args[] = "%$kw%"; $args[] = "%$kw%"; }
if ($brand) { $where[] = 'p.brand_id = ?'; $args[] = $brand; }
$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$order = ['asc' => 'p.price ASC', 'desc' => 'p.price DESC', 'new' => 'p.id DESC'][$sort] ?? 'p.id DESC';

$total = (int)q("SELECT COUNT(*) FROM products p JOIN brands b ON b.id = p.brand_id $w", $args)->fetchColumn();
$pages = max(1, (int)ceil($total / $per));
$page = min($page, $pages);
$rows = q("SELECT p.*, b.name AS brand FROM products p JOIN brands b ON b.id = p.brand_id $w ORDER BY $order LIMIT $per OFFSET " . (($page - 1) * $per), $args)->fetchAll();

function qs(array $over): string {
    $m = array_merge(['q' => $_GET['q'] ?? '', 'brand' => $_GET['brand'] ?? '', 'sort' => $_GET['sort'] ?? '', 'page' => ''], $over);
    return '?' . http_build_query(array_filter($m, fn($v) => $v !== '' && $v !== 0 && $v !== '0'));
}
include __DIR__ . '/includes/header.php';
$home = $kw === '' && !$brand && $page === 1;
?>
<?php if ($home): ?>
<section class="hero">
  <div>
    <div class="eyebrow">Cửa hàng điện thoại trực tuyến</div>
    <h1>Chọn điện thoại ưng ý, không cần đến tận cửa hàng.</h1>
    <p>Xem giá, so sánh cấu hình và đặt hàng ngay trên máy tính hoặc điện thoại. Đơn hàng được ghi nhận và theo dõi trạng thái ngay trên website.</p>
    <a class="btn" href="#san-pham">Xem sản phẩm</a>
  </div>
  <div class="sale" aria-label="Khuyến mãi Mega Sale">
    <div class="tag"><b>Mega Sale</b><span>Giảm đến 20% cho các mẫu chọn lọc.</span></div>
    <?php foreach (array_slice($rows, 0, 3) as $p) echo product_img($p, 'in-hero'); ?>
  </div>
</section>
<ol class="flow">
  <li><b>1</b><div><strong>Chọn sản phẩm</strong><span>Lọc theo hãng, giá hoặc từ khóa.</span></div></li>
  <li><b>2</b><div><strong>Thêm vào giỏ</strong><span>Chỉnh số lượng, xem tổng tiền.</span></div></li>
  <li><b>3</b><div><strong>Đăng nhập, đặt hàng</strong><span>Điền thông tin nhận hàng.</span></div></li>
  <li><b>4</b><div><strong>Xác nhận và giao</strong><span>Theo dõi trạng thái trong "Đơn của tôi".</span></div></li>
</ol>
<?php endif; ?>

<section id="san-pham" class="sec">
  <div class="sechead">
    <h2><?= $kw !== '' ? 'Kết quả cho "' . e($kw) . '"' : 'Danh sách sản phẩm' ?></h2>
    <div class="tools">
      <a class="chip" aria-pressed="<?= $brand ? 'false' : 'true' ?>" href="<?= e(qs(['brand' => '', 'page' => ''])) ?>#san-pham">Tất cả</a>
      <?php foreach ($brands as $b): ?>
        <a class="chip" aria-pressed="<?= $brand === (int)$b['id'] ? 'true' : 'false' ?>" href="<?= e(qs(['brand' => $b['id'], 'page' => ''])) ?>#san-pham"><?= e($b['name']) ?></a>
      <?php endforeach; ?>
      <form method="get" class="sortf">
        <input type="hidden" name="q" value="<?= e($kw) ?>"><input type="hidden" name="brand" value="<?= $brand ?>">
        <label>Sắp xếp
          <select name="sort" onchange="this.form.submit()">
            <option value="new" <?= $sort === 'new' ? 'selected' : '' ?>>Mới nhất</option>
            <option value="asc" <?= $sort === 'asc' ? 'selected' : '' ?>>Giá tăng dần</option>
            <option value="desc" <?= $sort === 'desc' ? 'selected' : '' ?>>Giá giảm dần</option>
          </select>
        </label>
        <noscript><button class="btn sm">Áp dụng</button></noscript>
      </form>
    </div>
  </div>

  <?php if (!$rows): ?>
    <p class="empty">Không tìm thấy sản phẩm phù hợp.</p>
  <?php else: ?>
  <div class="grid">
    <?php foreach ($rows as $p): $off = $p['old_price'] > $p['price'] ? (int)round((1 - $p['price'] / $p['old_price']) * 100) : 0; ?>
    <article class="card">
      <a class="art" href="<?= e(url('product.php?slug=' . $p['slug'])) ?>">
        <?php if ($off): ?><span class="off">-<?= $off ?>%</span><?php endif; ?>
        <?= product_img($p) ?>
      </a>
      <div class="body">
        <span class="brand"><?= e($p['brand']) ?></span>
        <h3><a href="<?= e(url('product.php?slug=' . $p['slug'])) ?>"><?= e($p['name']) ?></a></h3>
        <span class="spec"><?= e($p['spec']) ?></span>
        <div class="price"><b><?= money((int)$p['price']) ?></b><?php if ($off): ?><s><?= money((int)$p['old_price']) ?></s><?php endif; ?></div>
        <?php if ($p['stock'] > 0): ?>
        <form method="post" action="<?= e(url('cart.php')) ?>"><?= csrf_field() ?>
          <input type="hidden" name="action" value="add"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn full">Thêm vào giỏ</button></form>
        <?php else: ?><button class="btn ghost full" disabled>Hết hàng</button><?php endif; ?>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <?php if ($pages > 1): ?>
  <nav class="pager" aria-label="Phân trang">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <a class="chip" aria-pressed="<?= $i === $page ? 'true' : 'false' ?>" href="<?= e(qs(['page' => $i])) ?>#san-pham"><?= $i ?></a>
    <?php endfor; ?>
  </nav>
  <?php endif; ?>
  <?php endif; ?>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
