<?php
/**
 * Cài đặt CSDL: tạo bảng và nạp dữ liệu mẫu (tài khoản admin + sản phẩm).
 *   php database/install.php
 * Chạy lại nhiều lần vẫn an toàn: chỉ nạp dữ liệu khi bảng còn trống.
 */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$driver = cfg('db_driver');
if ($driver === 'mysql') {
    $dsn = 'mysql:host=' . cfg('db_host') . ';port=' . cfg('db_port') . ';charset=utf8mb4';
    $root = new PDO($dsn, cfg('db_user'), cfg('db_pass'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $root->exec(file_get_contents(__DIR__ . '/schema.mysql.sql'));
} else {
    db()->exec(file_get_contents(__DIR__ . '/schema.sqlite.sql'));
}

$out = PHP_SAPI === 'cli' ? fn($s) => print($s . PHP_EOL) : fn($s) => print(htmlspecialchars($s) . "<br>");

if ((int)q('SELECT COUNT(*) FROM users')->fetchColumn() === 0) {
    q('INSERT INTO users (username, password_hash, full_name, role, created_at) VALUES (?,?,?,?,?)',
      ['admin', password_hash('admin123', PASSWORD_DEFAULT), 'Quản trị viên', 'admin', now()]);
    $out('Đã tạo tài khoản quản trị: admin / admin123 (hãy đổi mật khẩu khi triển khai thật).');
}

if ((int)q('SELECT COUNT(*) FROM products')->fetchColumn() === 0) {
    // Giá và cấu hình là dữ liệu mẫu để minh họa, hãy chỉnh lại trong trang quản trị.
    $items = [
        ['Samsung', 'Galaxy S25', '12GB / 256GB, 6.2 inch, Snapdragon 8 Elite', 19990000, 22990000, 15],
        ['Samsung', 'Galaxy S24 Ultra', '12GB / 256GB, 6.8 inch, bút S Pen', 23990000, 28990000, 8],
        ['Samsung', 'Galaxy A56', '8GB / 256GB, 6.7 inch, pin 5000mAh', 10490000, 0, 30],
        ['Apple', 'iPhone 16', '128GB, 6.1 inch, chip A18', 21990000, 24990000, 12],
        ['Apple', 'iPhone 16 Pro Max', '256GB, 6.9 inch, chip A18 Pro', 33990000, 0, 6],
        ['Apple', 'iPhone 15', '128GB, 6.1 inch, chip A16 Bionic', 16990000, 19990000, 20],
        ['Xiaomi', 'Redmi Note 14', '8GB / 256GB, 6.67 inch, AMOLED 120Hz', 6290000, 0, 40],
        ['Xiaomi', 'Xiaomi 14T', '12GB / 256GB, 6.67 inch, camera Leica', 12490000, 13990000, 14],
        ['OPPO', 'OPPO Reno13', '12GB / 256GB, 6.59 inch, sạc nhanh 80W', 12990000, 0, 18],
        ['OPPO', 'OPPO A60', '8GB / 128GB, 6.67 inch, pin 5000mAh', 4990000, 5490000, 25],
        ['Google', 'Pixel 9', '12GB / 256GB, 6.3 inch, chip Tensor G4', 18990000, 0, 5],
        ['realme', 'realme 13 Pro', '12GB / 512GB, 6.7 inch, camera AI', 11990000, 12990000, 10],
    ];
    $brandId = [];
    foreach ($items as [$b, $n, $spec, $price, $old, $stock]) {
        if (!isset($brandId[$b])) {
            q('INSERT INTO brands (name) VALUES (?)', [$b]);
            $brandId[$b] = (int)db()->lastInsertId();
        }
        q('INSERT INTO products (brand_id, name, slug, spec, description, price, old_price, stock, image, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
          [$brandId[$b], $n, slugify($n), $spec,
           "$n chính hãng, bảo hành 12 tháng, đổi trả trong 7 ngày nếu có lỗi từ nhà sản xuất. Giao hàng toàn quốc, kiểm tra hàng khi nhận.",
           $price, $old, $stock, '', now()]);
    }
    $out('Đã nạp ' . count($items) . ' sản phẩm mẫu.');
    $out('Ảnh thật: chép file vào assets/img/products/ với tên <slug>.jpg (ví dụ iphone-16.jpg) hoặc upload trong trang quản trị.');
}
$out('Hoàn tất.');
