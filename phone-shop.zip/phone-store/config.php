<?php
return [
    'db_driver' => getenv('PS_DB_DRIVER') ?: 'mysql',
    'db_host'   => getenv('PS_DB_HOST') ?: '127.0.0.1',
    'db_port'   => getenv('PS_DB_PORT') ?: '3306',
    'db_name'   => getenv('PS_DB_NAME') ?: 'phone_store',
    'db_user'   => getenv('PS_DB_USER') ?: 'root',
    'db_pass'   => getenv('PS_DB_PASS') ?: 'PASSWORD-host',
    'sqlite_file' => __DIR__ . '/database/store.sqlite',

    'site_name' => 'Online Store',
    'per_page'  => 12,
    'max_upload_bytes' => 3 * 1024 * 1024,
];
