<?php
// Cấu hình kết nối. Có thể ghi đè bằng biến môi trường (PS_DB_DRIVER, PS_DB_HOST...).
return [
    // 'mysql' (theo báo cáo) hoặc 'sqlite' (chạy thử nhanh, không cần cài MySQL)
    'db_driver' => getenv('PS_DB_DRIVER') ?: 'mysql',
    'db_host'   => getenv('PS_DB_HOST') ?: '127.0.0.1',
    'db_port'   => getenv('PS_DB_PORT') ?: '3306',
    'db_name'   => getenv('PS_DB_NAME') ?: 'phone_store',
    'db_user'   => getenv('PS_DB_USER') ?: 'root',
    'db_pass'   => getenv('PS_DB_PASS') ?: '',
    'sqlite_file' => __DIR__ . '/database/store.sqlite',

    'site_name' => 'Online Store',
    'per_page'  => 12,
    'max_upload_bytes' => 3 * 1024 * 1024,
];
