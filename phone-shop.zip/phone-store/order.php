<?php
require __DIR__ . '/includes/bootstrap.php';
$user = require_login();
$o = q('SELECT * FROM orders WHERE code = ?', [$_GET['code'] ?? ''])->fetch();
if (!$o || ($o['user_id'] != $user['id'] && !is_admin())) { http_response_code(404); exit('Không tìm thấy đơn hàng.'); }
$items = q('SELECT * FROM order_items WHERE order_id = ?', [$o['id']])->fetchAll();
$title = 'Đơn ' . $o['code'];
include __DIR__ . '/includes/header.php';
?>
<h1 class="pt">Đơn hàng <?= e($o['code']) ?></h1>
<div class="cartwrap">
  <div class="panel">
    <p><span class="pill s-<?= e($o['status']) ?>"><?= e(STATUS[$o['status']]) ?></span> · đặt lúc <?= e($o['created_at']) ?></p>
    <div class="tblbox"><table class="tbl"><thead><tr><th>Sản phẩm</th><th>Đơn giá</th><th>SL</th><th>Thành tiền</th></tr></thead><tbody>
      <?php foreach ($items as $i): ?>
        <tr><td><?= e($i['name']) ?></td><td class="num"><?= money((int)$i['price']) ?></td><td><?= (int)$i['qty'] ?></td><td class="num"><?= money($i['price'] * $i['qty']) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <div class="total"><span>Tổng cộng</span><b><?= money((int)$o['total']) ?></b></div>
  </div>
  <aside class="sum">
    <h2>Nhận hàng</h2>
    <p><b><?= e($o['customer_name']) ?></b><br><?= e($o['phone']) ?><br><?= e($o['address']) ?></p>
    <?php if ($o['note']): ?><p class="note">Ghi chú: <?= e($o['note']) ?></p><?php endif; ?>
    <a class="btn ghost full" href="<?= e(url('orders.php')) ?>">Tất cả đơn của tôi</a>
  </aside>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
