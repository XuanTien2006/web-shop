<?php
require __DIR__ . '/includes/bootstrap.php';
$p = q('SELECT p.*, b.name AS brand FROM products p JOIN brands b ON b.id = p.brand_id WHERE p.slug = ?', [$_GET['slug'] ?? ''])->fetch();
if (!$p) { http_response_code(404); $title = 'Không tìm thấy'; include __DIR__ . '/includes/header.php'; echo '<p class="empty">Sản phẩm không tồn tại. <a href="' . e(url()) . '">Về trang chủ</a></p>'; include __DIR__ . '/includes/footer.php'; exit; }
$title = $p['name'];
$related = q('SELECT p.*, b.name AS brand FROM products p JOIN brands b ON b.id = p.brand_id WHERE p.brand_id = ? AND p.id <> ? ORDER BY p.id DESC LIMIT 4', [$p['brand_id'], $p['id']])->fetchAll();
$off = $p['old_price'] > $p['price'] ? (int)round((1 - $p['price'] / $p['old_price']) * 100) : 0;
include __DIR__ . '/includes/header.php';
?>
<p class="crumb"><a href="<?= e(url()) ?>">Trang chủ</a> / <a href="<?= e(url('index.php?brand=' . $p['brand_id'])) ?>"><?= e($p['brand']) ?></a> / <?= e($p['name']) ?></p>
<section class="detail">
  <div class="gallery"><?= product_img($p, 'big') ?></div>
  <div>
    <span class="brand"><?= e($p['brand']) ?></span>
    <h1><?= e($p['name']) ?></h1>
    <p class="spec"><?= e($p['spec']) ?></p>
    <div class="price lg"><b><?= money((int)$p['price']) ?></b><?php if ($off): ?><s><?= money((int)$p['old_price']) ?></s><span class="off inline">-<?= $off ?>%</span><?php endif; ?></div>
    <p class="stock <?= $p['stock'] > 0 ? 'in' : 'out' ?>"><?= $p['stock'] > 0 ? 'Còn ' . (int)$p['stock'] . ' sản phẩm' : 'Tạm hết hàng' ?></p>
    <?php if ($p['stock'] > 0): ?>
    <form method="post" action="<?= e(url('cart.php')) ?>" class="buy"><?= csrf_field() ?>
      <input type="hidden" name="action" value="add"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
      <label>Số lượng <input type="number" name="qty" value="1" min="1" max="<?= (int)$p['stock'] ?>"></label>
      <button class="btn">Thêm vào giỏ</button>
    </form>
    <?php endif; ?>
    <p class="desc"><?= nl2br(e($p['description'])) ?></p>
  </div>
</section>
<?php if ($related): ?>
<section class="sec"><div class="sechead"><h2>Cùng hãng <?= e($p['brand']) ?></h2></div>
  <div class="grid">
  <?php foreach ($related as $r): ?>
    <article class="card"><a class="art" href="<?= e(url('product.php?slug=' . $r['slug'])) ?>"><?= product_img($r) ?></a>
      <div class="body"><h3><a href="<?= e(url('product.php?slug=' . $r['slug'])) ?>"><?= e($r['name']) ?></a></h3>
      <div class="price"><b><?= money((int)$r['price']) ?></b></div></div></article>
  <?php endforeach; ?></div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
