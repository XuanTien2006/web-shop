<?php

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('#^/(includes|database)(/|$)#', $path) || preg_match('#/(config\.php|router\.php)$#', $path) || preg_match('#\.(sqlite|sql)$#', $path)) {
    http_response_code(403);
    exit('Forbidden');
}
return false;
