<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
$title = 'Quản trị';
$stat = [
    'Sản phẩm' => (int)q('SELECT COUNT(*) FROM products')->fetchColumn(),
    'Đơn chờ xác nhận' => (int)q("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn(),
    'Doanh thu (đơn hoàn tất)' => money((int)q("SELECT COALESCE(SUM(total),0) FROM orders WHERE status = 'done'")->fetchColumn()),
    'Khách hàng' => (int)q("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn(),
];
$low = q('SELECT name, stock FROM products WHERE stock <= 5 ORDER BY stock, name LIMIT 6')->fetchAll();
$latest = q('SELECT * FROM orders ORDER BY id DESC LIMIT 6')->fetchAll();
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1 class="pt">Tổng quan</h1>
<div class="stats">
  <?php foreach ($stat as $k => $v): ?><div class="stat"><span><?= e($k) ?></span><b><?= e($v) ?></b></div><?php endforeach; ?>
</div>
<div class="two">
  <section><h2>Đơn hàng mới nhất</h2>
    <?php if (!$latest): ?><p class="empty">Chưa có đơn hàng.</p><?php else: ?>
    <div class="tblbox"><table class="tbl"><tbody>
    <?php foreach ($latest as $o): ?>
      <tr><td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>"><?= e($o['code']) ?></a></td><td><?= e($o['customer_name']) ?></td><td class="num"><?= money((int)$o['total']) ?></td><td><span class="pill s-<?= e($o['status']) ?>"><?= e(STATUS[$o['status']]) ?></span></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </section>
  <section><h2>Sắp hết hàng</h2>
    <?php if (!$low): ?><p class="empty">Tồn kho ổn.</p><?php else: ?>
    <div class="tblbox"><table class="tbl"><tbody>
    <?php foreach ($low as $p): ?><tr><td><?= e($p['name']) ?></td><td class="num"><?= (int)$p['stock'] ?> còn lại</td></tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?>
  </section>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
