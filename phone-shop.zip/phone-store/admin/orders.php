<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
$st = $_GET['status'] ?? '';
$rows = isset(STATUS[$st])
    ? q('SELECT * FROM orders WHERE status = ? ORDER BY id DESC', [$st])->fetchAll()
    : q('SELECT * FROM orders ORDER BY id DESC')->fetchAll();
$title = 'Quản lý đơn hàng';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1 class="pt">Đơn hàng</h1>
<div class="tools" style="margin-bottom:14px">
  <a class="chip" aria-pressed="<?= $st === '' ? 'true' : 'false' ?>" href="<?= e(url('admin/orders.php')) ?>">Tất cả</a>
  <?php foreach (STATUS as $k => $label): ?><a class="chip" aria-pressed="<?= $st === $k ? 'true' : 'false' ?>" href="<?= e(url('admin/orders.php?status=' . $k)) ?>"><?= e($label) ?></a><?php endforeach; ?>
</div>
<?php if (!$rows): ?><p class="empty">Không có đơn hàng.</p><?php else: ?>
<div class="tblbox"><table class="tbl"><thead><tr><th>Mã đơn</th><th>Khách</th><th>Điện thoại</th><th>Tổng tiền</th><th>Ngày đặt</th><th>Trạng thái</th></tr></thead><tbody>
<?php foreach ($rows as $o): ?>
  <tr><td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>"><?= e($o['code']) ?></a></td><td><?= e($o['customer_name']) ?></td><td><?= e($o['phone']) ?></td><td class="num"><?= money((int)$o['total']) ?></td><td><?= e($o['created_at']) ?></td><td><span class="pill s-<?= e($o['status']) ?>"><?= e(STATUS[$o['status']]) ?></span></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
