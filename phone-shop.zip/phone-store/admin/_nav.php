<?php
require_admin();
$cur = basename($_SERVER['SCRIPT_NAME']);
$links = ['index.php' => 'Tổng quan', 'products.php' => 'Sản phẩm', 'orders.php' => 'Đơn hàng', 'feedback.php' => 'Phản hồi'];
?>
<div class="adminbar">
  <?php foreach ($links as $file => $label): ?>
    <a class="chip" aria-pressed="<?= $cur === $file || ($file === 'products.php' && $cur === 'product_edit.php') || ($file === 'orders.php' && $cur === 'order.php') ? 'true' : 'false' ?>" href="<?= e(url('admin/' . $file)) ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>
