<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    q('DELETE FROM feedback WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
    flash('Đã xóa phản hồi.');
    redirect('admin/feedback.php');
}
$rows = q('SELECT * FROM feedback ORDER BY id DESC')->fetchAll();
$title = 'Phản hồi khách hàng';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1 class="pt">Phản hồi khách hàng</h1>
<?php if (!$rows): ?><p class="empty">Chưa có phản hồi.</p><?php endif; ?>
<?php foreach ($rows as $r): ?>
  <article class="panel fb">
    <div class="sechead"><div><b><?= e($r['name']) ?></b> <span class="note"><?= e($r['email']) ?> · <?= e($r['created_at']) ?></span></div>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn ghost sm">Xóa</button></form></div>
    <p><?= nl2br(e($r['message'])) ?></p>
  </article>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
