<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
$id = (int)($_GET['id'] ?? 0);
$p = $id ? q('SELECT * FROM products WHERE id = ?', [$id])->fetch() : null;
if ($id && !$p) { http_response_code(404); exit('Không tìm thấy sản phẩm.'); }
$f = $p ?: ['name' => '', 'brand_id' => 0, 'spec' => '', 'description' => '', 'price' => '', 'old_price' => 0, 'stock' => 10, 'image' => '', 'slug' => ''];
$brandName = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f['name'] = trim((string)$_POST['name']);
    $brandName = trim((string)$_POST['brand']);
    $f['spec'] = trim((string)$_POST['spec']);
    $f['description'] = trim((string)$_POST['description']);
    $f['price'] = (int)$_POST['price'];
    $f['old_price'] = (int)$_POST['old_price'];
    $f['stock'] = (int)$_POST['stock'];

    if ($f['name'] === '' || $brandName === '') $err = 'Nhập tên sản phẩm và hãng.';
    elseif ($f['price'] < 1000) $err = 'Giá bán không hợp lệ.';
    elseif ($f['stock'] < 0) $err = 'Tồn kho không được âm.';
    else {
        $slug = $p ? $p['slug'] : slugify($f['name']);
        if (!$p && q('SELECT 1 FROM products WHERE slug = ?', [$slug])->fetch()) $slug .= '-' . substr(bin2hex(random_bytes(2)), 0, 3);
        [$img, $upErr] = save_upload($_FILES['image'] ?? [], $slug);
        if ($upErr) $err = $upErr;
        else {
            $b = q('SELECT id FROM brands WHERE name = ?', [$brandName])->fetchColumn();
            if (!$b) { q('INSERT INTO brands (name) VALUES (?)', [$brandName]); $b = db()->lastInsertId(); }
            if ($p) {
                if ($img) delete_image((string)$p['image']);
                q('UPDATE products SET brand_id=?, name=?, spec=?, description=?, price=?, old_price=?, stock=?, image=? WHERE id=?',
                  [$b, $f['name'], $f['spec'], $f['description'], $f['price'], $f['old_price'], $f['stock'], $img ?: $p['image'], $id]);
                flash('Đã cập nhật sản phẩm.');
            } else {
                q('INSERT INTO products (brand_id, name, slug, spec, description, price, old_price, stock, image, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                  [$b, $f['name'], $slug, $f['spec'], $f['description'], $f['price'], $f['old_price'], $f['stock'], $img ?: '', now()]);
                flash('Đã thêm sản phẩm.');
            }
            redirect('admin/products.php');
        }
    }
} elseif ($p) {
    $brandName = (string)q('SELECT name FROM brands WHERE id = ?', [$p['brand_id']])->fetchColumn();
}
$allBrands = q('SELECT name FROM brands ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);
$title = $p ? 'Sửa sản phẩm' : 'Thêm sản phẩm';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1 class="pt"><?= e($title) ?></h1>
<form method="post" enctype="multipart/form-data" class="panel formgrid"><?= csrf_field() ?>
  <?php if ($err): ?><div class="flash err full"><?= e($err) ?></div><?php endif; ?>
  <label>Tên sản phẩm<input type="text" name="name" value="<?= e($f['name']) ?>" required maxlength="120"></label>
  <label>Hãng<input type="text" name="brand" value="<?= e($brandName) ?>" required list="brands" maxlength="60"></label>
  <datalist id="brands"><?php foreach ($allBrands as $b) echo '<option value="' . e($b) . '">'; ?></datalist>
  <label class="full">Cấu hình ngắn<input type="text" name="spec" value="<?= e($f['spec']) ?>" maxlength="200" placeholder="8GB / 256GB, 6.7 inch"></label>
  <label>Giá bán (VNĐ)<input type="number" name="price" value="<?= e($f['price']) ?>" required min="1000" step="1000"></label>
  <label>Giá gốc (0 nếu không giảm)<input type="number" name="old_price" value="<?= e($f['old_price']) ?>" min="0" step="1000"></label>
  <label>Tồn kho<input type="number" name="stock" value="<?= e($f['stock']) ?>" min="0"></label>
  <label>Ảnh sản phẩm (JPG, PNG, WEBP, tối đa 3MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label>
  <?php if ($p): ?><div class="full curimg"><span class="note">Ảnh hiện tại</span><div class="thumb big"><?= product_img($p) ?></div></div><?php endif; ?>
  <label class="full">Mô tả<textarea name="description" rows="4"><?= e($f['description']) ?></textarea></label>
  <div class="full"><button class="btn"><?= $p ? 'Lưu thay đổi' : 'Thêm sản phẩm' ?></button> <a class="btn ghost" href="<?= e(url('admin/products.php')) ?>">Hủy</a></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
