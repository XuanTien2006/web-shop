<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $p = q('SELECT * FROM products WHERE id = ?', [$id])->fetch();
    if ($p) {
        q('DELETE FROM products WHERE id = ?', [$id]);
        delete_image((string)$p['image']);
        flash('Đã xóa sản phẩm "' . $p['name'] . '".');
    }
    redirect('admin/products.php');
}
$title = 'Quản lý sản phẩm';
$rows = q('SELECT p.*, b.name AS brand FROM products p JOIN brands b ON b.id = p.brand_id ORDER BY p.id DESC')->fetchAll();
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<div class="sechead"><h1 class="pt">Sản phẩm</h1><a class="btn" href="<?= e(url('admin/product_edit.php')) ?>">Thêm sản phẩm</a></div>
<div class="tblbox"><table class="tbl">
  <thead><tr><th>Sản phẩm</th><th>Hãng</th><th>Giá</th><th>Tồn</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $p): ?>
    <tr>
      <td><div class="cell"><div class="thumb"><?= product_img($p) ?></div><?= e($p['name']) ?></div></td>
      <td><?= e($p['brand']) ?></td><td class="num"><?= money((int)$p['price']) ?></td><td class="num"><?= (int)$p['stock'] ?></td>
      <td class="acts"><a class="btn ghost sm" href="<?= e(url('admin/product_edit.php?id=' . $p['id'])) ?>">Sửa</a>
        <form method="post" onsubmit="return confirm('Xóa sản phẩm này?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn ghost sm">Xóa</button></form></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
