<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
$id = (int)($_GET['id'] ?? 0);
$o = q('SELECT * FROM orders WHERE id = ?', [$id])->fetch();
if (!$o) { http_response_code(404); exit('Không tìm thấy đơn hàng.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $new = $_POST['status'] ?? '';
    if (isset(STATUS[$new]) && $new !== $o['status']) {
        $pdo = db(); $pdo->beginTransaction();
        // Hủy đơn thì hoàn lại tồn kho; khôi phục đơn đã hủy thì trừ lại.
        if ($new === 'cancelled' && $o['status'] !== 'cancelled') {
            foreach (q('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$id])->fetchAll() as $it)
                if ($it['product_id']) q('UPDATE products SET stock = stock + ? WHERE id = ?', [$it['qty'], $it['product_id']]);
        } elseif ($o['status'] === 'cancelled') {
            foreach (q('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$id])->fetchAll() as $it) {
                if ($it['product_id'] && !q('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [$it['qty'], $it['product_id'], $it['qty']])->rowCount()) {
                    $pdo->rollBack(); flash('Không đủ tồn kho để khôi phục đơn này.', 'err'); redirect('admin/order.php?id=' . $id);
                }
            }
        }
        q('UPDATE orders SET status = ? WHERE id = ?', [$new, $id]);
        $pdo->commit();
        flash('Đã cập nhật trạng thái đơn hàng.');
    }
    redirect('admin/order.php?id=' . $id);
}
$items = q('SELECT * FROM order_items WHERE order_id = ?', [$id])->fetchAll();
$title = 'Đơn ' . $o['code'];
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1 class="pt">Đơn <?= e($o['code']) ?></h1>
<div class="cartwrap">
  <div class="panel">
    <div class="tblbox"><table class="tbl"><thead><tr><th>Sản phẩm</th><th>Đơn giá</th><th>SL</th><th>Thành tiền</th></tr></thead><tbody>
      <?php foreach ($items as $i): ?><tr><td><?= e($i['name']) ?></td><td class="num"><?= money((int)$i['price']) ?></td><td><?= (int)$i['qty'] ?></td><td class="num"><?= money($i['price'] * $i['qty']) ?></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <div class="total"><span>Tổng cộng</span><b><?= money((int)$o['total']) ?></b></div>
  </div>
  <aside class="sum">
    <h2>Khách hàng</h2>
    <p><b><?= e($o['customer_name']) ?></b><br><?= e($o['phone']) ?><br><?= e($o['address']) ?></p>
    <?php if ($o['note']): ?><p class="note">Ghi chú: <?= e($o['note']) ?></p><?php endif; ?>
    <form method="post" class="stack"><?= csrf_field() ?>
      <label>Trạng thái
        <select name="status"><?php foreach (STATUS as $k => $label): ?><option value="<?= $k ?>" <?= $o['status'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select>
      </label>
      <button class="btn">Cập nhật</button>
    </form>
  </aside>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
