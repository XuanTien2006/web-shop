# Online Store – Website bán điện thoại (PHP + MySQL)

Đồ án Web theo báo cáo: khách hàng đăng ký, đăng nhập, xem danh mục, tìm kiếm, giỏ hàng, đặt hàng, gửi phản hồi;
quản trị viên thêm/sửa/xóa sản phẩm (có upload ảnh), xử lý đơn hàng, xem phản hồi.

## Chạy bằng XAMPP (MySQL)
1. Chép thư mục `phone-store` vào `htdocs`, bật Apache và MySQL trong XAMPP.
2. Sửa `config.php` nếu MySQL của bạn có mật khẩu (mặc định user `root`, không mật khẩu).
3. Tạo CSDL và nạp dữ liệu mẫu, mở Terminal tại thư mục dự án:
   `php database/install.php`
   (hoặc nhập `database/schema.mysql.sql` trong phpMyAdmin rồi chạy lệnh trên để nạp admin + sản phẩm).
4. Mở http://localhost/phone-store/

## Chạy thử nhanh không cần MySQL (SQLite)
```
PS_DB_DRIVER=sqlite php database/install.php
PS_DB_DRIVER=sqlite php -S localhost:8000 router.php
```
Mở http://localhost:8000/ (trên Windows PowerShell dùng `$env:PS_DB_DRIVER="sqlite"` trước mỗi lệnh).

## Tài khoản
- Quản trị: `admin` / `admin123` (đổi mật khẩu khi triển khai thật)
- Khách hàng: tự đăng ký ở trang Đăng ký

## Ảnh điện thoại thật
Có hai cách:
1. Trang quản trị > Sản phẩm > Sửa > chọn "Ảnh sản phẩm" (JPG/PNG/WEBP, tối đa 3MB).
2. Chép file ảnh vào `assets/img/products/` đặt tên theo slug của sản phẩm, ví dụ `iphone-16.jpg`, `galaxy-s25.png`.
   Website tự nhận ảnh này. Sản phẩm chưa có ảnh sẽ hiện hình điện thoại vẽ sẵn.
Nên dùng ảnh nền trắng hoặc trong suốt, tỉ lệ dọc. Chỉ dùng ảnh bạn có quyền sử dụng.

## Cấu trúc
- `index.php`, `product.php`, `cart.php`, `checkout.php`, `order.php`, `orders.php`, `contact.php`, `login.php`, `register.php`, `logout.php`: trang khách hàng
- `admin/`: tổng quan, sản phẩm, đơn hàng, phản hồi
- `includes/bootstrap.php`: kết nối CSDL (PDO), phiên đăng nhập, CSRF, giỏ hàng, upload ảnh
- `database/`: `schema.mysql.sql`, `schema.sqlite.sql`, `install.php`

## Bảo mật đã làm
Câu lệnh SQL tham số hóa (PDO), mật khẩu băm bằng `password_hash`, token CSRF cho mọi form POST, escape đầu ra,
kiểm tra loại file ảnh bằng nội dung thật, phân quyền admin ở mọi trang quản trị, giá và tồn kho luôn đọc lại từ CSDL
khi đặt hàng (trong một giao dịch), hủy đơn tự hoàn tồn kho.
