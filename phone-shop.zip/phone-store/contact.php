<?php
require __DIR__ . '/includes/bootstrap.php';
$user = current_user();
$f = ['name' => $user['full_name'] ?? '', 'email' => $user['email'] ?? '', 'message' => ''];
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($f as $k => $_) $f[$k] = trim((string)($_POST[$k] ?? ''));
    if ($f['name'] === '' || $f['message'] === '') $err = 'Vui lòng nhập họ tên và nội dung phản hồi.';
    elseif (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $err = 'Email không hợp lệ.';
    else {
        q('INSERT INTO feedback (user_id, name, email, message, created_at) VALUES (?,?,?,?,?)', [$user['id'] ?? null, $f['name'], $f['email'], mb_substr($f['message'], 0, 2000), now()]);
        flash('Cảm ơn bạn, phản hồi đã được gửi tới quản trị viên.');
        redirect('contact.php');
    }
}
$title = 'Liên hệ và phản hồi';
include __DIR__ . '/includes/header.php';
?>
<form method="post" class="panel stack narrow"><?= csrf_field() ?>
  <h1>Gửi phản hồi</h1>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <label>Họ và tên<input type="text" name="name" value="<?= e($f['name']) ?>" required></label>
  <label>Email<input type="text" name="email" value="<?= e($f['email']) ?>" required></label>
  <label>Nội dung<textarea name="message" rows="5" maxlength="2000" required><?= e($f['message']) ?></textarea></label>
  <button class="btn">Gửi phản hồi</button>
</form>
<?php include __DIR__ . '/includes/footer.php'; ?>
